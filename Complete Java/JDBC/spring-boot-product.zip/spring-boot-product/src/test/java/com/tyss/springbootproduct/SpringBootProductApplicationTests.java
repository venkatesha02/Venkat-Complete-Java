package com.tyss.springbootproduct;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootProductApplicationTests {

	@Test
	void contextLoads() {
	}

}
