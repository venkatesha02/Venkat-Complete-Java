<h2 align="center">Patrocinadores de Material-UI</h2>

The core of Material-UI is a [crowd-funded](/discover-more/backers/) open-source project, licensed under the permissive MIT license. El patrocinio aumenta la tasa de corrección de errores, mejoras de documentación y desarrollo de funciones futuras.

### Diamante 💎

*%s espacios disponibles*

Diamond Sponsors are those who have pledged $2,000/month or more to Material-UI. Por favor, póngase en contacto con nosotros en diamond@material-ui.com para suscribirse a este nivel.

### Oro 🏆

via [Patreon](https://www.patreon.com/oliviertassinari)

<p style="display: flex; justify-content: center;">
  <a data-ga-event-category="sponsors" data-ga-event-action="logo" data-ga-event-label="tidelift" href="https://tidelift.com/subscription/pkg/npm-material-ui?utm_source=material_ui&utm_medium=referral&utm_campaign=homepage" rel="noopener sponsored" target="_blank" style="margin-right: 16px;"><img width="96" src="https://github.com/tidelift.png?size=96" alt="tidelift" title="Enterprise-ready open source software" /></a>
  <a data-ga-event-category="sponsors" data-ga-event-action="logo" data-ga-event-label="bitsrc" href="https://bit.dev" rel="noopener sponsored" target="_blank" style="margin-right: 16px;"><img width="96" src="https://github.com/teambit.png?size=96" alt="bitsrc" title="La forma más rápida de compartir código" /></a>
</p>

a través de [OpenCollective](https://opencollective.com/material-ui)

<p style="display: flex; justify-content: center; flex-wrap: wrap;">
  <a data-ga-event-category="sponsors" data-ga-event-action="logo" data-ga-event-label="callemall" href="https://www.call-em-all.com" rel="noopener sponsored" target="_blank" style="margin-right: 16px;"><img src="https://images.opencollective.com/proxy/images?src=https%3A%2F%2Fopencollective-production.s3-us-west-1.amazonaws.com%2Ff4053300-e0ea-11e7-acf0-0fa7c0509f4e.png&height=100" alt="call-em-all" title="La forma fácil de enviar mensajes a su grupo" width="100" loading="lazy"></a>
</p>

Gold Sponsors are those who have pledged $500/month or more to Material-UI.

### ¡Y aún hay más!

Revise la lista de todos [nuestros patrocinadores](/discover-more/backers/).