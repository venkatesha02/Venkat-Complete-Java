<h2 align="center">Material-UI 的赞助商</h2>

Material-UI 是一个[众筹](/discover-more/backers/)的开源项目，根据MIT协议进行许可。 赞助可用加快我们错误修复，文档改进和功能开发的速度。

### 钻石级💎

*3/3 个位置可用*

Diamond Sponsors are those who have pledged $2,000/month or more to Material-UI. 请联系邮箱 diamond@material-ui.com 以订阅此级别。

### 金杯级 🏆

通过 [Patreon](https://www.patreon.com/oliviertassinari)

<p style="display: flex; justify-content: center;">
  <a data-ga-event-category="sponsors" data-ga-event-action="logo" data-ga-event-label="tidelift" href="https://tidelift.com/subscription/pkg/npm-material-ui?utm_source=material_ui&utm_medium=referral&utm_campaign=homepage" rel="noopener sponsored" target="_blank" style="margin-right: 16px;"><img width="96" src="https://github.com/tidelift.png?size=96" alt="tidelift" title="企业级开源软件" /></a>
  <a data-ga-event-category="sponsors" data-ga-event-action="logo" data-ga-event-label="bitsrc" href="https://bit.dev" rel="noopener sponsored" target="_blank" style="margin-right: 16px;"><img width="96" src="https://github.com/teambit.png?size=96" alt="bitsrc" title="分享你的代码最快的办法" /></a>
</p>

通过 [OpenCollective](https://opencollective.com/material-ui)

<p style="display: flex; justify-content: center; flex-wrap: wrap;">
  <a data-ga-event-category="sponsors" data-ga-event-action="logo" data-ga-event-label="callemall" href="https://www.call-em-all.com" rel="noopener sponsored" target="_blank" style="margin-right: 16px;"><img src="https://images.opencollective.com/proxy/images?src=https%3A%2F%2Fopencollective-production.s3-us-west-1.amazonaws.com%2Ff4053300-e0ea-11e7-acf0-0fa7c0509f4e.png&height=100" alt="call-em-all" title="向群组发送消息的最简便的方法" width="100" loading="lazy"></a>
</p>

Gold Sponsors are those who have pledged $500/month or more to Material-UI.

### 其实还有更多！

查看[我们赞助商](/discover-more/backers/)的完整名单。